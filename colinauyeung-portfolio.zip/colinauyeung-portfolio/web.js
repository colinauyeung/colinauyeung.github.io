var path = require('path');
var express = require('express');
var bodyParser = require('body-parser');
var cors = require('cors');
var app = express();
const PORT = process.env.PORT || 5000;

const { Client } = require('pg');

const select = "select * from messages\n" +
    "where sender != $1\n" +
    "and host = $2\n" +
    "and ti > $3;";

const insert = "insert into messages (id, sender, host, emotion, body, ti)\n" +
    "values (nextval('messagecount'), $1, $2, $3, $4, $5);\n";

const gethost = "select * from connections\n" +
    "where sender = $1\n" +
    "and host = $2;";

const inserthost = "insert into connections(id, sender, host)\n" +
    "values (nextval('connectcount'), $1, $2);";

const gethosts = "select * from connections\n" +
    "where host = $1;";

const deleteuuid = "delete from connections\n" +
    "where sender = $1" +
    "and host = $2;";

const deletemessages = "delete from messages\n" +
    "where ti < $1;";

const firstping = "insert into pings (id, sender, host, time)\n" +
    "values (nextval('pingseq'), $1, $2, $3); \n";

const updatehosts = "update pings set time = $1\n" +
    "where sender = $2" +
    "and host = $3;";

const checkpings = "select * from pings\n" +
    "where time < $1;";

const deletepings = "delete from pings\n" +
    "where time < $1;";





//TODO: Make Pinging system


// app.use(express.static(path.join(__dirname, 'public')))
//     .get('/', (req, res) => {
//         res.sendFile(path.join(__dirname, 'public/pages/index.html'))
//     })
//
// .listen(PORT);

const client = new Client({
    connectionString: process.env.DATABASE_URL,
    ssl: {
        rejectUnauthorized: false
    }
});

client.connect();

// var allowCrossDomain = function(req, res, next) {
//     res.header('Access-Control-Allow-Origin', '*');
//     res.header('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE,OPTIONS');
//     res.header('Access-Control-Allow-Headers', 'Content-Type, Authorization, Content-Length, X-Requested-With');
//
//     // intercept OPTIONS method
//     if ('OPTIONS' == req.method) {
//         res.send(200);
//     }
//     else {
//         next();
//     }
// };


app.use(cors());
app.use(bodyParser.urlencoded({extended: false}));
app.use (bodyParser.json());

var router = express.Router();

router.post("/messages", function (req, res){
    var uuid = req.body.uuid;
    var hostcode = req.body.host;
    var emotion = req.body.emotion;
    var message = req.body.message;
    var time = new Date(Date.now());
    client.query(insert, [uuid, hostcode, emotion, message, time.toISOString()])
        .then(res1  => {res.json({message: 'success'})})
        .catch(e => {throw e});

    // client.query("insert into messages (id, sender, host, emotion, body, ti)\n" +
    //     `values (nextval('messagecount'), '${uuid}', '${hostcode}', '${emotion}', '${message}',  '${time.toISOString()}');`, (err1,  res1) => {
    //     // client.query('select * from messages;', (err1,  res1) => {
    //     if (err1) throw err1;
    //
    // });
});

router.post("/getmessages", function (req, res){
    var uuid = req.body.uuid;
    var host = req.body.host;
    var time = req.body.time;
    var now = new Date(Date.now());


    client.query(select, [uuid, host, time])
        .then(res1  =>{
            var tres = [];
            for (let row of res1.rows){
                tres.push(row);
            }
            res.json({message: tres});
        })
        .catch(e => {throw e});

    client.query(updatehosts, [now, uuid, host])
        .catch(e => {throw e});



});

router.post("/initping", function(req, res){
    var uuid = req.body.uuid;
    var host = req.body.host;
    var time = new Date(Date.now());
    client.query(firstping, [uuid, host, time.toISOString()])
        .catch(e => {throw e});
    res.json({message: "success"})
});

router.post("/host", function(req, res){
  var uuid = req.body.uuid;
  var host = req.body.host;
  var checkt = new Date(Date.now() - 300000);

  client.query(checkpings, [checkt.toISOString()])
      .then(res1 => {
          // var tres = [];
          for (let row of res1.rows){
              // tres.push(row);
              ruuid = row.sender;
              rhost = row.host;

              client.query(deleteuuid, [ruuid, rhost])
                  .then(res2 => {})
                  .catch(e => {throw e});
          }

          // res.json({message : tres});
      })
      .catch(e => {throw e});

  client.query(deletemessages, [checkt.toISOString()])
      .catch(e => {throw e});

  client.query(deletepings, [checkt.toISOString()])
      .catch(e => {throw e});

  client.query(gethost, [uuid, host])
      .then(res1 => {
          var tres = [];
          for (let row of res1.rows){
              tres.push(row);
          }
          if(tres.length <= 0){
              client.query(inserthost, [uuid, host])
                  .then( res2 => {
                      res.json({message: "success"})
                  })
                  .catch(e => {throw e});
          }
          else{
              res.json({message: "failure"});
         }
      })
      .catch(e => {throw e});
});

router.post("/endhost", function(req, res){
   var uuid = req.body.uuid;
   var host = req.body.host;

   client.query(deleteuuid, [uuid, host])
       .then(res1 => {
           client.query(gethosts, [host])
               .then(res2 =>{
                   var tres = [];
                   for (let row of res2.rows){
                       tres.push(row);
                   }
                   if(tres.length <= 0){
                       client.query(deletemessages, [host])
                   }
                   res.json({message: "deleted"})
               })
       })
});

app.use("/api",  router);
app.listen(PORT);